<?php
require_once '../includes/auth_check.php';
if ($isLoggedIn) {
    header('Location: ../dashboard/dashboard.php');
    exit();
}
require_once '../includes/header.php';
?>

<div class="auth-overlay d-flex align-items-center justify-content-center">
    <div class="neu-card p-5 text-center fade-in">
        <div class="neu-icon-box mb-4 mx-auto">
            <i class="bi bi-book-half display-4 text-maroon"></i>
        </div>
        <h2 class="title-font text-maroon mb-3">E-OBRA</h2>
        <p class="mb-4">Maligayang pagdating sa interaktibong pag-aaral ng Noli Me Tangere.</p>
        
        <button id="google-login-btn" class="neu-btn w-100 d-flex align-items-center justify-content-center gap-2">
            <img src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/google.svg" width="20" alt="Google">
            Mag-login gamit ang Google
        </button>
        <p class="mt-4 text-muted small">Walang account? Mag-login gamit ang Google upang makapag-sign up.</p>
    </div>
</div>
<script src="auth.js"></script>

<?php require_once '../includes/footer.php'; ?>
