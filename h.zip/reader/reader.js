let glossaryData = [];
let currentChapterId = null;
let currentChapterNum = null;
let rawChapterContent = "";
let chapterSentences = [];
let currentPage = 0;
const sentencesPerPage = 20;

// Load Glossary from API
async function fetchGlossary(chapterId = 1) {
    try {
        const response = await fetch(BASE_URL + `api/get_glossary.php?chapter_id=${chapterId}`);
        const data = await response.json();
        if (data.status === 'success') {
            glossaryData = data.data;
        }
    } catch (error) {
        console.error("Hindi makuha ang glossary:", error);
    }
}

// Highlight words from glossary
function highlightGlossaryWords(text) {
    if (!glossaryData || glossaryData.length === 0) return text;

    let highlightedText = text;
    const sortedWords = [...glossaryData].sort((a, b) => b.word.length - a.word.length);

    sortedWords.forEach(item => {
        const regex = new RegExp(`\\b(${item.word})\\b`, 'gi');
        highlightedText = highlightedText.replace(regex, (match) => {
            return `<span class="glossary-term" data-word="${item.word}">${match}</span>`;
        });
    });

    return highlightedText;
}

async function loadChapter(num) {
    currentChapterNum = num;
    await fetchGlossary(num);

    try {
        const response = await fetch(BASE_URL + `api/get_chapter.php?num=${num}`);
        const data = await response.json();

        if (data.status === 'success') {
            const chapter = data.data;
            currentChapterId = chapter.id;
            currentChapterNum = parseInt(chapter.chapter_number);
            rawChapterContent = chapter.content;
            document.getElementById('chapter-title').innerText = `Kabanata ${chapter.chapter_number}: ${chapter.title}`;

            // Split content into sentences
            // Using regex to split by . ! or ? followed by whitespace or end of string
            const rawContent = chapter.content.replace(/\n\n/g, " "); // Flatten paragraphs for sentence flow
            chapterSentences = rawContent.match(/[^\.!\?]+[\.!\?]+/g) || [rawContent];

            // Clean up sentences
            chapterSentences = chapterSentences.map(s => s.trim()).filter(s => s.length > 0);

            currentPage = 0;
            document.getElementById('next-chapter-btn').classList.add('d-none');
            displayPage();
        }
    } catch (error) {
        console.error("Error loading chapter:", error);
    }
}

function displayPage() {
    const contentDiv = document.getElementById('chapter-content');
    contentDiv.classList.remove('fade-in');
    void contentDiv.offsetWidth;
    contentDiv.classList.add('fade-in');

    const start = currentPage * sentencesPerPage;
    const end = start + sentencesPerPage;
    const sentencesToShow = chapterSentences.slice(start, end);

    // Join sentences and highlight words
    const pageText = sentencesToShow.join(" ");
    const highlightedContent = highlightGlossaryWords(pageText);

    contentDiv.innerHTML = `<div class="reader-page-content">${highlightedContent}</div>`;

    setupGlossaryEvents();
    document.getElementById('page-indicator').innerText = `Pahina ${currentPage + 1} ng ${Math.ceil(chapterSentences.length / sentencesPerPage)}`;

    document.getElementById('prev-btn').disabled = (currentPage === 0);
    const isLastPage = (end >= chapterSentences.length);
    document.getElementById('next-btn').disabled = isLastPage;

    if (isLastPage) {
        document.getElementById('next-chapter-btn').classList.remove('d-none');
    } else {
        document.getElementById('next-chapter-btn').classList.add('d-none');
    }
}

function startReading(chapterNum) {
    loadChapter(chapterNum);
}

// Pagination
document.getElementById('prev-btn').addEventListener('click', () => {
    if (currentPage > 0) {
        currentPage--;
        displayPage();
        window.scrollTo({ top: 100, behavior: 'smooth' });
    }
});

document.getElementById('next-btn').addEventListener('click', () => {
    if ((currentPage + 1) * sentencesPerPage < chapterSentences.length) {
        currentPage++;
        displayPage();
        window.scrollTo({ top: 100, behavior: 'smooth' });
    }
});

// Glossary logic
function setupGlossaryEvents() {
    const chapterDiv = document.getElementById('chapter-content');
    const terms = chapterDiv.querySelectorAll('.glossary-term');
    terms.forEach(term => {
        term.addEventListener('click', (e) => {
            showTooltip(e, term.dataset.word);
        });
    });

    chapterDiv.addEventListener('dblclick', (e) => {
        // If the target is already a glossary term, let the click handler handle it
        if (e.target.classList.contains('glossary-term')) return;

        const selection = window.getSelection().toString().trim().toLowerCase();
        if (selection) {
            const cleanSelection = selection.replace(/[.,\/#!$%\^&\*;:{}=\-_`~()]/g, "");
            showTooltip(e, cleanSelection);
        }
    });
}

function showTooltip(e, word) {
    const tooltip = document.getElementById('glossary-tooltip');
    const match = glossaryData.find(item => item.word.toLowerCase() === word.toLowerCase());

    if (match) {
        document.getElementById('tooltip-word').innerText = match.word;
        document.getElementById('tooltip-definition').innerText = match.definition;

        // Prevent clicking inside the tooltip from closing it
        tooltip.onclick = (event) => event.stopPropagation();

        let x = e.clientX;
        let y = e.clientY - 120;

        if (x + 300 > window.innerWidth) x = window.innerWidth - 320;
        if (y < 0) y = e.clientY + 20;

        tooltip.style.left = `${x}px`;
        tooltip.style.top = `${y}px`;
        tooltip.classList.add('active');

        // Close when clicking outside
        const closeHandler = (event) => {
            if (!tooltip.contains(event.target)) {
                hideTooltip();
                document.removeEventListener('click', closeHandler);
            }
        };

        setTimeout(() => {
            document.addEventListener('click', closeHandler);
        }, 100);
    }
}

function hideTooltip() {
    const tooltip = document.getElementById('glossary-tooltip');
    if (tooltip) tooltip.classList.remove('active');
}

// PDF Export - Native Print Preview Approach (Same Tab)
document.getElementById('download-pdf').addEventListener('click', function() {
    const chapterNum = currentChapterNum;
    window.location.href = BASE_URL + `reader/print.php?chapter=${chapterNum}`;
});

document.getElementById('next-chapter-btn').addEventListener('click', () => {
    if (currentChapterNum < 64) {
        window.location.href = BASE_URL + `reader/reader.php?book=noli&chapter=${currentChapterNum + 1}`;
    }
});
