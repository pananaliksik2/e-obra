<?php
require_once '../includes/auth_check.php';
if (!$isLoggedIn) {
    header('Location: ../auth/login.php');
    exit();
}
$book = isset($_GET['book']) ? $_GET['book'] : 'noli';
$chapter = isset($_GET['chapter']) ? $_GET['chapter'] : 1;
require_once '../includes/header.php';
?>

<link rel="stylesheet" href="reader.css">

<div id="reader-view" class="fade-in">
    <div class="d-flex justify-content-between align-items-center mb-4 px-2">
        <button class="neu-btn-sm text-maroon border-0 bg-transparent" onclick="location.href='../chapters/chapters.php?book=<?php echo $book; ?>'">
            <i class="bi bi-arrow-left me-1"></i> Bumalik sa mga Kabanata
        </button>
    </div>

    <div class="neu-container p-4 p-md-5 mb-4" id="chapter-reader">
        <div class="text-center mb-5">
            <h2 class="chapter-title-neu" id="chapter-title">Ikinakarga...</h2>
            <div class="neu-divider mx-auto"></div>
        </div>
        
        <div class="chapter-content-neu" id="chapter-content">
            <!-- Content goes here -->
        </div>

        <div class="d-flex justify-content-center align-items-center gap-4 mt-5">
            <button class="neu-btn-icon" id="prev-btn" title="Nakaraang Pahina">
                <i class="bi bi-chevron-left"></i>
            </button>
            <span class="neu-page-indicator" id="page-indicator">Pahina 1</span>
            <button class="neu-btn-icon" id="next-btn" title="Susunod na Pahina">
                <i class="bi bi-chevron-right"></i>
            </button>
        </div>
    </div>

    <div class="d-flex flex-wrap justify-content-center gap-3">
        <button class="neu-btn d-flex align-items-center gap-2" id="download-pdf">
            <i class="bi bi-file-earmark-pdf"></i> I-download bilang PDF
        </button>
        <button class="neu-btn d-flex align-items-center gap-2" id="start-quiz">
            <i class="bi bi-pencil-square"></i> Pagsusulit
        </button>
        <button class="neu-btn d-flex align-items-center gap-2 d-none" id="next-chapter-btn">
            Susunod <i class="bi bi-arrow-right"></i>
        </button>
    </div>
</div>

<script src="reader.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', () => {
        if (typeof startReading === 'function') {
            startReading(<?php echo $chapter; ?>);
        }
    });
</script>

<?php require_once '../includes/footer.php'; ?>
