<?php
require_once '../includes/auth_check.php';
if (!$isLoggedIn) {
    die("Unauthorized");
}

$chapter_num = isset($_GET['chapter']) ? intval($_GET['chapter']) : 1;

require_once '../includes/db_connect.php';

// Fetch Chapter
$stmt = $pdo->prepare("SELECT * FROM chapters WHERE chapter_number = ?");
$stmt->execute([$chapter_num]);
$chapter = $stmt->fetch();

// Fetch Glossary
$stmt = $pdo->prepare("SELECT * FROM glossary WHERE chapter_id = ?");
$stmt->execute([$chapter_num]);
$glossary = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="tl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kabanata <?php echo $chapter['chapter_number']; ?>: <?php echo $chapter['title']; ?></title>
    <style>
        :root {
            --maroon: #800000;
            --paper-bg: #ffffff;
            --desk-bg: #f4f4f9;
        }
        
        body {
            margin: 0;
            padding: 0;
            background-color: var(--desk-bg);
            font-family: 'Times New Roman', Times, serif;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        /* Fixed Navigation Bar */
        .preview-controls {
            position: sticky;
            top: 0;
            width: 100%;
            background: rgba(244, 244, 249, 0.8);
            backdrop-filter: blur(12px);
            -webkit-backdrop-filter: blur(12px);
            padding: 15px 0;
            display: flex;
            justify-content: center;
            gap: 20px;
            z-index: 100;
            box-shadow: 0 2px 15px rgba(0,0,0,0.05);
            border-bottom: 1px solid rgba(255,255,255,0.3);
        }

        .neu-action-btn {
            background: #f0f0f0;
            border: 1px solid rgba(255,255,255,0.6);
            padding: 10px 25px;
            border-radius: 12px;
            box-shadow: 5px 5px 10px #cbcbcb, -5px -5px 10px #ffffff;
            cursor: pointer;
            font-weight: 600;
            color: var(--maroon);
            transition: all 0.3s ease;
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 14px;
        }

        .neu-action-btn:hover {
            transform: translateY(-2px);
            box-shadow: 7px 7px 14px #cbcbcb, -7px -7px 14px #ffffff;
        }

        .neu-action-btn:active {
            transform: translateY(0);
            box-shadow: inset 3px 3px 6px #cbcbcb, inset -3px -3px 6px #ffffff;
        }

        .neu-action-btn.primary {
            background: var(--maroon);
            color: white;
            border: none;
            box-shadow: 5px 5px 10px #b0b0b0;
        }

        .neu-action-btn.primary:hover {
            background: #a00000;
            box-shadow: 7px 7px 14px #b0b0b0;
        }

        /* Paper Sheet Styling */
        .paper-sheet {
            background: var(--paper-bg);
            width: 8.5in;
            min-height: 13in;
            padding: 1in;
            margin: 40px 0;
            box-shadow: 0 10px 40px rgba(0,0,0,0.1);
            position: relative;
            box-sizing: border-box;
            border-radius: 2px;
        }

        .header {
            text-align: center;
            margin-bottom: 40px;
        }
        .header h1 {
            color: var(--maroon);
            font-size: 24pt;
            margin: 0 0 5px 0;
            text-transform: uppercase;
            letter-spacing: 1.5px;
        }
        .header p {
            font-size: 10pt;
            color: #777;
            margin: 0;
            font-style: italic;
        }
        .divider {
            border-bottom: 2pt solid var(--maroon);
            width: 1.2in;
            margin: 15px auto;
        }

        .content {
            text-align: justify;
            font-size: 12pt;
            line-height: 1.7;
            color: #222;
        }
        .content p {
            margin-bottom: 18pt;
            text-indent: 0.5in;
        }

        .glossary {
            margin-top: 60px;
            border-top: 1pt solid #eee;
            padding-top: 30px;
        }
        .glossary h2 {
            color: var(--maroon);
            font-size: 18pt;
            margin-bottom: 20px;
        }
        .glossary-item {
            margin-bottom: 12px;
            font-size: 11pt;
        }
        .glossary-item b {
            color: var(--maroon);
        }

        .footer-tag {
            margin-top: 60px;
            text-align: center;
            font-size: 9pt;
            color: #aaa;
            border-top: 1px solid #f0f0f0;
            padding-top: 20px;
        }

        /* Mobile Design Responsiveness */
        @media (max-width: 8.5in) {
            .preview-controls {
                padding: 12px 10px;
                gap: 10px;
            }
            .neu-action-btn {
                padding: 12px 10px;
                font-size: 12px;
                border-radius: 10px;
                flex: 1;
                justify-content: center;
                box-shadow: 4px 4px 8px #d1d1d1, -4px -4px 8px #ffffff;
            }
            .neu-action-btn i {
                font-size: 14px;
            }
            .paper-sheet {
                width: 100%;
                margin: 0;
                padding: 40px 20px;
                box-shadow: none;
                border-radius: 0;
            }
            .header h1 {
                font-size: 1.8rem;
            }
            .content {
                font-size: 1.15rem;
            }
        }

        /* Print Override */
        @media print {
            body { background: none !important; }
            .preview-controls { display: none !important; }
            .paper-sheet {
                margin: 0 !important;
                box-shadow: none !important;
                width: 100% !important;
                padding: 0 !important;
            }
            @page {
                size: 8.5in 13in;
                margin: 0.75in;
            }
        }
    </style>
</head>
<body>
    <div class="preview-controls no-print">
        <a href="../chapters/chapters.php" class="neu-action-btn">
            ← Bumalik sa mga Kabanata
        </a>
        <button class="neu-action-btn primary" onclick="window.print()">
            I-download / I-print PDF
        </button>
    </div>

    <div class="paper-sheet">
        <div class="header">
            <h1>Kabanata <?php echo $chapter['chapter_number']; ?></h1>
            <h1><?php echo $chapter['title']; ?></h1>
            <p>E-Obra: Panitikan at Teknolohiya - Noli Me Tangere</p>
            <div class="divider"></div>
        </div>

        <div class="content">
            <?php 
            $paragraphs = explode("\n\n", $chapter['content']);
            foreach ($paragraphs as $p) {
                if (trim($p)) {
                    echo "<p>" . htmlspecialchars($p) . "</p>";
                }
            }
            ?>
        </div>

        <?php if (!empty($glossary)): ?>
        <div class="glossary">
            <h2>Talahulugan (Glossary)</h2>
            <?php foreach ($glossary as $item): ?>
            <div class="glossary-item">
                <b><?php echo htmlspecialchars($item['word']); ?>:</b> 
                <?php echo htmlspecialchars($item['definition']); ?>
            </div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>

        <div class="footer-tag">
            © 2026 E-Obra Platform | Panitikan at Teknolohiya
        </div>
    </div>
</body>
</html>
