async function selectBook(bookKey) {
    if (bookKey === 'noli') {
        window.location.href = BASE_URL + 'chapters/chapters.php?book=noli';
    } else {
        alert("Ang 'El Filibusterismo' ay paparating pa lamang. Manatiling nakasubaybay!");
    }
}

function startReading(chapterNum) {
    window.location.href = BASE_URL + `reader/reader.php?book=noli&chapter=${chapterNum}`;
}
