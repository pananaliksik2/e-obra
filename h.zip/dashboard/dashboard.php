<?php
require_once '../includes/auth_check.php';
if (!$isLoggedIn) {
    header('Location: ../auth/login.php');
    exit();
}
require_once '../includes/header.php';
?>

<link rel="stylesheet" href="dashboard.css">

<div id="library-view" class="fade-in">
    <div class="row g-4 justify-content-center">
        <div class="col-md-5 col-lg-4">
            <div class="neu-card p-3 h-100 book-card" onclick="location.href='../chapters/chapters.php?book=noli'">
                <div class="book-cover-container mb-3">
                    <div class="book-spine"></div>
                    <div class="book-title-overlay">
                        <h5 class="title-font text-white">NOLI ME TANGERE</h5>
                        <small class="text-white">Jose Rizal</small>
                    </div>
                </div>
                <h4 class="title-font text-maroon text-center">Noli Me Tangere</h4>
                <p class="text-center small text-muted">Huwag Mo Akong Salingin</p>
                <button class="neu-btn w-100 mt-2">Simulan ang Pagbabasa</button>
            </div>
        </div>
        <div class="col-md-5 col-lg-4">
            <div class="neu-card p-3 h-100 book-card">
                <div class="book-cover-container fili-cover mb-3">
                    <div class="book-spine"></div>
                    <div class="book-title-overlay">
                        <h5 class="title-font text-white">EL FILIBUSTERISMO</h5>
                        <small class="text-white">Jose Rizal</small>
                    </div>
                </div>
                <h4 class="title-font text-maroon text-center">El Filibusterismo</h4>
                <p class="text-center small text-muted">Ang Paghahari ng Kasakiman</p>
                <button class="neu-btn w-100 mt-2" disabled>Abangan...</button>
            </div>
        </div>
    </div>
</div>

<script src="dashboard.js"></script>
<?php require_once '../includes/footer.php'; ?>
