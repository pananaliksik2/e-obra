<?php
require_once '../includes/db_connect.php';

header('Content-Type: application/json');

$chapter_number = isset($_GET['num']) ? intval($_GET['num']) : 1;

try {
    $stmt = $pdo->prepare("SELECT * FROM chapters WHERE chapter_number = ?");
    $stmt->execute([$chapter_number]);
    $chapter = $stmt->fetch();
    
    if ($chapter) {
        echo json_encode(['status' => 'success', 'data' => $chapter]);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Ang kabanata ay hindi nahanap.']);
    }
} catch (PDOException $e) {
    echo json_encode(['status' => 'error', 'message' => 'May kamalian: ' . $e->getMessage()]);
}
?>
