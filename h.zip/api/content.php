<?php
/**
 * E-Obra Content API
 * GET: Fetch chapter content + glossary by chapter_id
 * Query param: ?chapter_id=X
 */

require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    sendError('Tanging GET method lamang ang tinatanggap.', 405);
}

$chapter_id = isset($_GET['chapter_id']) ? intval($_GET['chapter_id']) : 0;

if ($chapter_id <= 0) {
    sendError('Kinakailangan ang wastong chapter_id.');
}

$pdo = getDBConnection();

try {
    // Get chapter info
    $chapterStmt = $pdo->prepare("SELECT * FROM chapters WHERE chapter_id = :cid");
    $chapterStmt->execute([':cid' => $chapter_id]);
    $chapter = $chapterStmt->fetch();

    if (!$chapter) {
        sendError('Hindi natagpuan ang kabanata.', 404);
    }

    // Get paragraphs
    $contentStmt = $pdo->prepare(
        "SELECT content_id, paragraph_order, paragraph_text 
         FROM chapter_contents 
         WHERE chapter_id = :cid 
         ORDER BY paragraph_order ASC"
    );
    $contentStmt->execute([':cid' => $chapter_id]);
    $paragraphs = $contentStmt->fetchAll();

    // Get glossary
    $glossaryStmt = $pdo->prepare(
        "SELECT term_id, archaic_word, modern_definition 
         FROM glossary 
         WHERE chapter_id = :cid 
         ORDER BY archaic_word ASC"
    );
    $glossaryStmt->execute([':cid' => $chapter_id]);
    $glossary = $glossaryStmt->fetchAll();

    sendResponse([
        'status' => 'success',
        'chapter' => $chapter,
        'paragraphs' => $paragraphs,
        'glossary' => $glossary
    ]);
} catch (PDOException $e) {
    sendError('Hindi makuha ang nilalaman: ' . $e->getMessage(), 500);
}
?>
