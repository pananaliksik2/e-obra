<?php
/**
 * E-Obra Progress API
 * POST: Submit quiz answers & save progress
 * POST: Mark chapter as read
 */

require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendError('Tanging POST method lamang ang tinatanggap.', 405);
}

$input = json_decode(file_get_contents('php://input'), true);

if (!$input) {
    sendError('Hindi wastong format ng datos.');
}

$action = $input['action'] ?? '';
$user_id = intval($input['user_id'] ?? 0);
$chapter_id = intval($input['chapter_id'] ?? 0);

if ($user_id <= 0 || $chapter_id <= 0) {
    sendError('Kinakailangan ang wastong user_id at chapter_id.');
}

$pdo = getDBConnection();

try {
    if ($action === 'mark_read') {
        // Mark chapter as read
        $stmt = $pdo->prepare("
            INSERT INTO student_progress (user_id, chapter_id, is_read)
            VALUES (:uid, :cid, TRUE)
            ON DUPLICATE KEY UPDATE is_read = TRUE
        ");
        $stmt->execute([':uid' => $user_id, ':cid' => $chapter_id]);

        sendResponse([
            'status' => 'success',
            'message' => 'Na-mark na bilang nabasa ang kabanata.'
        ]);

    } elseif ($action === 'submit_quiz') {
        // Validate quiz answers server-side
        $answers = $input['answers'] ?? [];

        if (empty($answers)) {
            sendError('Walang sagot na naisumite.');
        }

        // Get correct answers from DB
        $placeholders = implode(',', array_fill(0, count($answers), '?'));
        $questionIds = array_keys($answers);
        
        $stmt = $pdo->prepare(
            "SELECT assessment_id, correct_option FROM assessments 
             WHERE chapter_id = ? AND assessment_id IN ($placeholders)"
        );
        $params = array_merge([$chapter_id], $questionIds);
        $stmt->execute($params);
        $correctAnswers = $stmt->fetchAll();

        $score = 0;
        $totalItems = count($correctAnswers);
        $results = [];

        foreach ($correctAnswers as $qa) {
            $qId = $qa['assessment_id'];
            $isCorrect = (strtoupper($answers[$qId] ?? '') === strtoupper($qa['correct_option']));
            if ($isCorrect) $score++;
            $results[$qId] = [
                'submitted' => $answers[$qId] ?? '',
                'correct' => $qa['correct_option'],
                'is_correct' => $isCorrect
            ];
        }

        // Save or update progress
        $progressStmt = $pdo->prepare("
            INSERT INTO student_progress (user_id, chapter_id, is_read, quiz_score, total_items, completed_at)
            VALUES (:uid, :cid, TRUE, :score, :total, CURRENT_TIMESTAMP)
            ON DUPLICATE KEY UPDATE 
                quiz_score = :score2, 
                total_items = :total2, 
                is_read = TRUE,
                completed_at = CURRENT_TIMESTAMP
        ");
        $progressStmt->execute([
            ':uid' => $user_id,
            ':cid' => $chapter_id,
            ':score' => $score,
            ':total' => $totalItems,
            ':score2' => $score,
            ':total2' => $totalItems
        ]);

        sendResponse([
            'status' => 'success',
            'message' => 'Matagumpay na naisumite ang pagsusulit.',
            'score' => $score,
            'total_items' => $totalItems,
            'percentage' => round(($score / max($totalItems, 1)) * 100),
            'results' => $results
        ]);

    } else {
        sendError('Hindi kilalang aksyon. Gamitin ang "mark_read" o "submit_quiz".');
    }

} catch (PDOException $e) {
    sendError('May error sa database: ' . $e->getMessage(), 500);
}
?>
