<?php
session_start();
require_once '../includes/db_connect.php';

header('Content-Type: application/json');

if (isset($_SESSION['user_id'])) {
    $stmt = $pdo->prepare("SELECT session_token FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch();

    if ($user && isset($_SESSION['session_token']) && $user['session_token'] === $_SESSION['session_token']) {
        echo json_encode(['status' => 'active']);
    } else {
        // Mismatch
        session_destroy();
        echo json_encode(['status' => 'terminated']);
    }
} else {
    echo json_encode(['status' => 'logged_out']);
}
?>
