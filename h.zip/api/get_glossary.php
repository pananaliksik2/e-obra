<?php
require_once '../includes/db_connect.php';

header('Content-Type: application/json');

$chapter_id = isset($_GET['chapter_id']) ? (int)$_GET['chapter_id'] : 1;

try {
    $stmt = $pdo->prepare("SELECT word, definition, modern_context FROM glossary WHERE chapter_id = ?");
    $stmt->execute([$chapter_id]);
    $glossary = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode(['status' => 'success', 'data' => $glossary]);
} catch (PDOException $e) {
    echo json_encode(['status' => 'error', 'message' => 'Hindi nakuha ang talahulugan: ' . $e->getMessage()]);
}
?>
