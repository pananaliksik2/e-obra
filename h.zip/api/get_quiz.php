<?php
require_once '../includes/db_connect.php';

header('Content-Type: application/json');

$chapter_id = isset($_GET['chapter_id']) ? intval($_GET['chapter_id']) : 0;

try {
    // Get quiz for this chapter
    $stmt = $pdo->prepare("SELECT id FROM quizzes WHERE chapter_id = ?");
    $stmt->execute([$chapter_id]);
    $quiz = $stmt->fetch();
    
    if ($quiz) {
        $quiz_id = $quiz['id'];
        // Get questions
        $stmt = $pdo->prepare("SELECT * FROM questions WHERE quiz_id = ?");
        $stmt->execute([$quiz_id]);
        $questions = $stmt->fetchAll();
        
        echo json_encode(['status' => 'success', 'data' => $questions]);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Walang pagsusulit para sa kabanatang ito.']);
    }
} catch (PDOException $e) {
    echo json_encode(['status' => 'error', 'message' => 'May kamalian: ' . $e->getMessage()]);
}
?>
