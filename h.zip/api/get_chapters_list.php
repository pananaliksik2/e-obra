<?php
require_once '../includes/db_connect.php';

header('Content-Type: application/json');

try {
    $stmt = $pdo->query("SELECT id, chapter_number, title FROM chapters ORDER BY chapter_number ASC");
    $chapters = $stmt->fetchAll();
    
    echo json_encode(['status' => 'success', 'data' => $chapters]);
} catch (PDOException $e) {
    echo json_encode(['status' => 'error', 'message' => 'May kamalian: ' . $e->getMessage()]);
}
?>
