<?php
session_start();
require_once '../includes/db_connect.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);

    if (isset($input['uid'], $input['first_name'], $input['last_name'])) {
        $uid = $input['uid'];
        $first_name = $input['first_name'];
        $last_name = $input['last_name'];
        $email = isset($input['email']) ? $input['email'] : '';

        try {
            $session_token = bin2hex(random_bytes(32));

            // Check if user exists
            $stmt = $pdo->prepare("SELECT * FROM users WHERE firebase_uid = ?");
            $stmt->execute([$uid]);
            $user = $stmt->fetch();

            if ($user) {
                // Update email if it's currently empty, and update session_token
                if (empty($user['email']) && !empty($email)) {
                    $updateStmt = $pdo->prepare("UPDATE users SET email = ?, session_token = ? WHERE id = ?");
                    $updateStmt->execute([$email, $session_token, $user['id']]);
                } else {
                    $updateStmt = $pdo->prepare("UPDATE users SET session_token = ? WHERE id = ?");
                    $updateStmt->execute([$session_token, $user['id']]);
                }

                // User exists, log them in (set session here)
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['firebase_uid'] = $user['firebase_uid'];
                $_SESSION['first_name'] = $user['first_name'];
                $_SESSION['last_name'] = $user['last_name'];
                $_SESSION['session_token'] = $session_token;
                
                echo json_encode(['status' => 'success', 'message' => 'Matagumpay na pag-login.', 'user' => $user]);
            } else {
                // Register new user
                $stmt = $pdo->prepare("INSERT INTO users (firebase_uid, first_name, last_name, email, session_token) VALUES (?, ?, ?, ?, ?)");
                $stmt->execute([$uid, $first_name, $last_name, $email, $session_token]);
                
                $new_user_id = $pdo->lastInsertId();
                $_SESSION['user_id'] = $new_user_id;
                $_SESSION['firebase_uid'] = $uid;
                $_SESSION['first_name'] = $first_name;
                $_SESSION['last_name'] = $last_name;
                $_SESSION['session_token'] = $session_token;
                
                echo json_encode(['status' => 'success', 'message' => 'Matagumpay na pagrehistro.', 'user_id' => $new_user_id]);
            }
        } catch (PDOException $e) {
            echo json_encode(['status' => 'error', 'message' => 'May kamalian sa pagproseso: ' . $e->getMessage()]);
        }
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Kulang ang impormasyong ipinadala.']);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Maling pamamaraan (Method Not Allowed).']);
}
?>
