<?php
/**
 * E-Obra Chapters API
 * GET: Fetch all chapters with optional user progress
 * Query param: ?user_id=X
 */

require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    sendError('Tanging GET method lamang ang tinatanggap.', 405);
}

$pdo = getDBConnection();
$user_id = isset($_GET['user_id']) ? intval($_GET['user_id']) : 0;

try {
    if ($user_id > 0) {
        // With progress
        $stmt = $pdo->prepare("
            SELECT 
                c.chapter_id,
                c.chapter_number,
                c.title,
                c.chapter_summary,
                COALESCE(sp.is_read, 0) AS is_read,
                COALESCE(sp.quiz_score, 0) AS quiz_score,
                COALESCE(sp.total_items, 0) AS total_items,
                sp.completed_at
            FROM chapters c
            LEFT JOIN student_progress sp ON c.chapter_id = sp.chapter_id AND sp.user_id = :uid
            ORDER BY c.chapter_number ASC
        ");
        $stmt->execute([':uid' => $user_id]);
    } else {
        $stmt = $pdo->query("SELECT * FROM chapters ORDER BY chapter_number ASC");
    }

    $chapters = $stmt->fetchAll();

    sendResponse([
        'status' => 'success',
        'chapters' => $chapters
    ]);
} catch (PDOException $e) {
    sendError('Hindi makuha ang mga kabanata: ' . $e->getMessage(), 500);
}
?>
