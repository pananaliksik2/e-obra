<?php
/**
 * E-Obra Quiz API
 * GET: Fetch quiz questions for a chapter
 * Query param: ?chapter_id=X
 */

require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    sendError('Tanging GET method lamang ang tinatanggap.', 405);
}

$chapter_id = isset($_GET['chapter_id']) ? intval($_GET['chapter_id']) : 0;

if ($chapter_id <= 0) {
    sendError('Kinakailangan ang wastong chapter_id.');
}

$pdo = getDBConnection();

try {
    // Verify chapter exists
    $chapterStmt = $pdo->prepare("SELECT chapter_id, chapter_number, title FROM chapters WHERE chapter_id = :cid");
    $chapterStmt->execute([':cid' => $chapter_id]);
    $chapter = $chapterStmt->fetch();

    if (!$chapter) {
        sendError('Hindi natagpuan ang kabanata.', 404);
    }

    // Get questions (do NOT send correct_option to client for security — validate on server)
    $quizStmt = $pdo->prepare(
        "SELECT assessment_id, question_text, option_a, option_b, option_c, option_d
         FROM assessments 
         WHERE chapter_id = :cid 
         ORDER BY assessment_id ASC"
    );
    $quizStmt->execute([':cid' => $chapter_id]);
    $questions = $quizStmt->fetchAll();

    sendResponse([
        'status' => 'success',
        'chapter' => $chapter,
        'total_items' => count($questions),
        'questions' => $questions
    ]);
} catch (PDOException $e) {
    sendError('Hindi makuha ang pagsusulit: ' . $e->getMessage(), 500);
}
?>
