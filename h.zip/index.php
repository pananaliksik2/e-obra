<?php
require_once 'includes/auth_check.php';

header('Location: dashboard/dashboard.php');
exit();
?>
