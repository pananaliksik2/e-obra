<?php 
// Dynamic base URL detection
$protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http";
$host = $_SERVER['HTTP_HOST'];
$script_name = $_SERVER['SCRIPT_NAME'];

// Detect if we are in a subdirectory (like /E-Obra/) or at the root
if (strpos($script_name, '/E-Obra/') !== false) {
    $base_url = $protocol . "://" . $host . "/E-Obra/";
} else {
    // If not in /E-Obra/, assume we are at the root (standard for InfinityFree)
    $base_url = $protocol . "://" . $host . "/";
}

$current_page = basename($_SERVER['PHP_SELF']); 
?>
<!DOCTYPE html>
<html lang="fil">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>E-Obra: Panitikan at Teknolohiya</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@400;700&family=Faustina:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo $base_url; ?>css/style.css">
</head>
<body class="bg-neu">

<?php 
$current_page = basename($_SERVER['PHP_SELF']); 
?>
<?php if ($isLoggedIn): ?>
    <nav class="navbar navbar-expand-lg neu-nav mb-5">
        <div class="container">
            <a class="navbar-brand title-font text-maroon <?php echo ($current_page == 'dashboard.php') ? 'active' : ''; ?>" href="<?php echo $base_url; ?>dashboard/dashboard.php" id="brand-home">
                <i class="bi bi-feather me-2"></i>E-OBRA
            </a>
            <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto gap-3">
                    <li class="nav-item">
                        <a class="nav-link neu-nav-link <?php echo ($current_page == 'dashboard.php' || $current_page == 'chapters.php') ? 'active' : ''; ?>" id="nav-library" href="<?php echo $base_url; ?>dashboard/dashboard.php">
                            <i class="bi bi-collection me-1"></i>Aklatan
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link neu-nav-link <?php echo ($current_page == 'reader.php') ? 'active' : ''; ?>" id="nav-reader" href="#">
                            <i class="bi bi-journal-text me-1"></i>Pagbabasa
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link neu-nav-link" id="nav-quiz" href="#">
                            <i class="bi bi-pencil-square me-1"></i>Pagsusulit
                        </a>
                    </li>

                </ul>
            </div>
        </div>
    </nav>
<?php endif; ?>

<main class="container mb-5">
