<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Authentication bypassed - Always logged in
$isLoggedIn = true;
$sessionTerminated = false;
?>
