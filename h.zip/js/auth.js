// Firebase Configuration
const firebaseConfig = {
    apiKey: "AIzaSyBAiZpz5w0-kwRN-NnERdSSWX2x5HMf5-Q",
    authDomain: "e-obra-32b9d.firebaseapp.com",
    projectId: "e-obra-32b9d",
    storageBucket: "e-obra-32b9d.firebasestorage.app",
    messagingSenderId: "776500024564",
    appId: "1:776500024564:web:ccdde8fa5502a5d636baa1",
    measurementId: "G-L73MH145QD"
};

// Initialize Firebase
if (!firebase.apps.length) {
    firebase.initializeApp(firebaseConfig);
}
const auth = firebase.auth();
const provider = new firebase.auth.GoogleAuthProvider();

// Monitor session live
let sessionCheckInterval = null;

function startSessionMonitor() {
    if (sessionCheckInterval) clearInterval(sessionCheckInterval);
    sessionCheckInterval = setInterval(() => {
        fetch(BASE_URL + 'api/check_session.php?t=' + new Date().getTime())
            .then(res => res.json())
            .then(data => {
                if (data.status === 'terminated' || data.status === 'logged_out') {
                    stopSessionMonitor();
                    auth.signOut().then(() => {
                        window.location.href = BASE_URL + 'auth/login.php';
                    });
                }
            })
            .catch(err => console.error("Session monitor error:", err));
    }, 10000);
}

function stopSessionMonitor() {
    if (sessionCheckInterval) clearInterval(sessionCheckInterval);
}

// Global Auth Listener
auth.onAuthStateChanged((user) => {
    if (user) {
        startSessionMonitor();
        if (typeof isPhpLoggedIn !== 'undefined' && !isPhpLoggedIn) {
            syncUserWithMySQL(user);
        }
    } else {
        stopSessionMonitor();
        if (typeof isPhpLoggedIn !== 'undefined' && isPhpLoggedIn) {
            fetch(BASE_URL + 'api/logout.php').then(() => {
                window.location.href = BASE_URL + 'auth/login.php';
            });
        }
    }
});

function syncUserWithMySQL(firebaseUser) {
    const displayName = firebaseUser.displayName || "";
    const names = displayName.split(" ");
    const userData = {
        uid: firebaseUser.uid,
        first_name: names[0],
        last_name: names.slice(1).join(" ") || "",
        email: firebaseUser.email
    };

    fetch(BASE_URL + 'api/login.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(userData)
    })
    .then(res => res.json())
    .then(data => {
        if (data.status === 'success') {
            const isLoginPage = window.location.pathname.includes('login.php');
            if (isLoginPage) {
                window.location.href = BASE_URL + 'dashboard/dashboard.php';
            }
        }
    });
}

// Add Logout Button Listener (Robust for Mobile)
document.addEventListener('click', (e) => {
    // Check if the clicked element or its parent is the logout button
    const logoutBtn = e.target.closest('#logout-btn');
    
    if (logoutBtn) {
        e.preventDefault();
        console.log("Logout initiated...");
        
        auth.signOut().then(() => {
            console.log("Logged out successfully");
            // The onAuthStateChanged listener handles the redirect
        }).catch((error) => {
            console.error("Sign out error:", error);
            alert("Nagkaroon ng problema sa pag-logout. Pakisubukang muli.");
        });
    }
});
