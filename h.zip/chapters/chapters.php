<?php
require_once '../includes/auth_check.php';
if (!$isLoggedIn) {
    header('Location: ../auth/login.php');
    exit();
}
$book = isset($_GET['book']) ? $_GET['book'] : 'noli';
require_once '../includes/header.php';
?>

<link rel="stylesheet" href="chapters.css">

<div id="chapter-list-view" class="neu-container p-4 p-md-5 fade-in">
    <div class="mb-4">
        <button class="neu-btn-sm text-maroon border-0 bg-transparent p-0" onclick="location.href='../dashboard/dashboard.php'">
            <i class="bi bi-arrow-left me-1"></i> Bumalik sa Aklatan
        </button>
    </div>

    <div class="text-center mb-5">
        <h2 class="title-font text-maroon" id="book-title-header"><?php echo ($book == 'noli' ? 'Noli Me Tangere' : 'El Filibusterismo'); ?></h2>
        <p class="text-muted">Pumili ng kabanata upang simulan ang pagbabasa</p>
        <div class="neu-divider mx-auto"></div>
    </div>

    <!-- Search Section -->
    <div class="row justify-content-center mb-4">
        <div class="col-md-6">
            <div class="neu-search-wrapper">
                <i class="bi bi-search text-maroon"></i>
                <input type="number" id="chapter-search" class="neu-input-search" placeholder="Maghanap ng Kabanata (Hal. 1-64)..." min="1" max="64">
            </div>
        </div>
    </div>
    
    <div class="row justify-content-center">
        <div class="col-md-10 col-lg-8">
            <div class="row g-3" id="chapter-list-container">
                <!-- Chapter items will be injected here via JS -->
            </div>
        </div>
    </div>
    
</div>

<script src="chapters.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', () => {
        if (typeof selectBook === 'function') {
            selectBook('<?php echo $book; ?>');
        }
    });
</script>

<?php require_once '../includes/footer.php'; ?>
