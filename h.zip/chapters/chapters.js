let allChapters = [];

async function selectBook(bookKey) {
    if (bookKey === 'noli') {
        try {
            const response = await fetch(BASE_URL + 'api/get_chapters_list.php');
            const data = await response.json();
            
            if (data.status === 'success') {
                allChapters = data.data;
                renderChapters(allChapters);
            }
        } catch (error) {
            console.error("Error loading chapter list:", error);
        }
    }
}

function renderChapters(chapters) {
    const container = document.getElementById('chapter-list-container');
    if (!container) return;

    if (chapters.length === 0) {
        container.innerHTML = '<div class="col-12 text-center text-muted p-4">Walang nahanap na kabanata.</div>';
        return;
    }

    let html = '';
    chapters.forEach(chapter => {
        html += `
        <div class="col-12 mb-2 chapter-item-wrapper">
            <div class="chapter-item-neu" onclick="startReading(${chapter.chapter_number})">
                <div class="d-flex align-items-center">
                    <div class="chapter-num">${chapter.chapter_number}</div>
                    <div class="chapter-title">${chapter.title}</div>
                </div>
                <i class="bi bi-chevron-right text-muted"></i>
            </div>
        </div>`;
    });
    container.innerHTML = html;
}

// Search Functionality
document.getElementById('chapter-search')?.addEventListener('input', function(e) {
    const searchTerm = e.target.value.trim();
    
    if (searchTerm === "") {
        renderChapters(allChapters);
    } else {
        const filtered = allChapters.filter(c => 
            c.chapter_number.toString().includes(searchTerm)
        );
        renderChapters(filtered);
    }
});

function startReading(chapterNum) {
    window.location.href = BASE_URL + `reader/reader.php?book=noli&chapter=${chapterNum}`;
}
